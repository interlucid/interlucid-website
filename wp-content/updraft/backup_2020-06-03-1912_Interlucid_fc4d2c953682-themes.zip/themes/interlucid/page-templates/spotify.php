<?php

// Template Name: Spotify

print(file_get_contents('https://open.spotify.com/artist/1sUfSWX6BIlZZqlMWBFZ6m?si=926gZf1NRbm0DVg8eigGGw'));