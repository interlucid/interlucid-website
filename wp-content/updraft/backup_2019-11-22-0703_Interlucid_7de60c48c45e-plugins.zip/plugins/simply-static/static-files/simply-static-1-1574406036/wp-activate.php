<!DOCTYPE html>
<html>
	<head>
		<title>Redirecting...</title>
		<meta http-equiv="refresh" content="0;url=/wp-login.php?action=register">
	</head>
	<body>
		<script type="text/javascript">
			window.location = "/wp-login.php?action=register";
		</script>

		<p>You are being redirected to <a href="/wp-login.php?action=register">/wp-login.php?action=register</a></p>
	</body>
</html>
