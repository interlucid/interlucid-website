[![Netlify Status](https://api.netlify.com/api/v1/badges/46cba20f-0067-47aa-90c2-e38ad2f4f5f5/deploy-status)](https://app.netlify.com/sites/interlucid/deploys)

# Interlucid Website

In an effort to reduce the amount of time required to update the website, I decided to move to a WordPress/Bootstrap installation.  Hopefully this means new content will be released faster and look prettier.
