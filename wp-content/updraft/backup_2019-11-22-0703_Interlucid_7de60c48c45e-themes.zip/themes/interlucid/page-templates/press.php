<?php

// Template Name: Press

get_header();

?>

<div class="container pt-6 text-center">
    <h1 class="mb-4">Press</h1>
    <p><a href="http://www.webaudioweekly.com/88" target="_blank">Web Audio Weekly</a></p>
    <p><a href="https://www.cityweekly.net/BuzzBlog/archives/2017/01/13/local-releases-pigeon-holding-a-shupecabra" target="_blank">Salt Lake City Weekly</a></p>
</div>

<?php get_footer(); ?>